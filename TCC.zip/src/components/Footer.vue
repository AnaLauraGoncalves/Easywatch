<template>
  <!--Pronto-->
  <footer class="footer">
      <span class="text-muted"> Easywatch© 2022 </span>
  </footer>
</template>

<script>
export default {
  name: "footer-vue",
};
</script>
<style>
.footer {
  background-color: #090c1a;
  margin-bottom: 0;
  width: 100%;
  text-align: center;
}

</style>
